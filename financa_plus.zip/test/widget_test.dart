import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Teste inicial', (WidgetTester tester) async {
    expect(1 + 1, 2);
  });
}
